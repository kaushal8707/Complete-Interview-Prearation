package com.java.selfdeveloped.spring.java8.api.lambda.exression;

public class MyFunctionalImpl {

	public static void main(String[] args) {

		MyFunctionalInterface mfi = 
							()-> System.out.println("Inside method m1");
		mfi.m1();
		mfi.m2();
		MyFunctionalInterface.m4();
	}

}

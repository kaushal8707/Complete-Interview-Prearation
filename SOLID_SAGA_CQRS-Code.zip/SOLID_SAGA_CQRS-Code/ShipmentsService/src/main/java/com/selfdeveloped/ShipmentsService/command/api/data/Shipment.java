package com.selfdeveloped.ShipmentsService.command.api.data;
import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@Entity
@Table(name = "shipments")
public class Shipment {
	
	@Id
	private String shipmentId;
	private String orderId;
	private String shipmentStatus;
}



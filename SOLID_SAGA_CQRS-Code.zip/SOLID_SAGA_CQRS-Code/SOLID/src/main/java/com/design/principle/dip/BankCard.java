package com.design.principle.dip;

public interface BankCard {

	public void doTransaction(long amount);
}

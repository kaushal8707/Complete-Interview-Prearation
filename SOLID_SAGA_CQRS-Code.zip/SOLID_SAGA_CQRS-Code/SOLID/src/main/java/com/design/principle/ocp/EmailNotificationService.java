package com.design.principle.ocp;

public class EmailNotificationService implements NotificationService{

	@Override
	public void sendOTP(String medium) {
		//write logic to integrate with Email API
	}

	@Override
	public void sendTransactionReport(String medium) {
		//write logic to integrate with Email API
	}

}

package com.design.principle.lsp.solution;

public class Instagram implements SocialMedia,PostMediaManager{

    public void publishPost(Object post) {

    }

    public void chatWithFriend() {

    }

    public void sendPhotosAndVideos() {

    }
}

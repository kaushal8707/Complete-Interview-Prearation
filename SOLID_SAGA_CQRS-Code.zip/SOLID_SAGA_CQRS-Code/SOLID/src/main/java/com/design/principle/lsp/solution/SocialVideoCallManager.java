package com.design.principle.lsp.solution;

public interface SocialVideoCallManager {
    public void groupVideoCall(String... users);
}

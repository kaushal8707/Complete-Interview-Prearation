package com.design.principle.isp;

public class Phonepe implements UPIPayments {
    public void payMoney() {

    }

    public void getScratchCard() {

    }

	@Override
	public void getCashBackAsCreditBalance() {
		// Not applicable in PhonePay
		
	}


}

package com.design.principle.isp.solution;

public interface CashBackManager {

    public void getCashBackAsCreditBalance();
}

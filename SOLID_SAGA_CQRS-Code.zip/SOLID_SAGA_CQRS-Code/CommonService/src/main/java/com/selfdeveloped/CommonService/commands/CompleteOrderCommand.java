package com.selfdeveloped.CommonService.commands;
import org.axonframework.modelling.command.TargetAggregateIdentifier;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;

@Getter
@Builder
public class CompleteOrderCommand {

	@TargetAggregateIdentifier
	private String orderId;
	private String orderStatus;
	
}



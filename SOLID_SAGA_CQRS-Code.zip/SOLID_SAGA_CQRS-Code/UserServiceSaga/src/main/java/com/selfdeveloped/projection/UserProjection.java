package com.selfdeveloped.projection;
import org.axonframework.queryhandling.QueryHandler;
import org.springframework.stereotype.Component;

import com.selfdeveloped.CommonService.model.CardDetails;
import com.selfdeveloped.CommonService.model.User;
import com.selfdeveloped.CommonService.queries.GetUserPaymentDetailsQuery;

@Component
public class UserProjection {

	@QueryHandler
	public User getUserPaymentDetails(GetUserPaymentDetailsQuery query) {
		
		// Ideally get the details from the DB
		
		CardDetails cardDetails=
				CardDetails.builder()
				.name("Kaushal Singh")
				.validUntilYear(2025)
				.validUntilMonth(1)
				.cardNumber("1234567890")
				.cvv(8707)
				.build();
		
		return User.builder()
				.userId(query.getUserId())
				.firstName("Kaushal")
				.lastName("Singh")
				.cardDetails(cardDetails)
				.build(); 
		
		
	}
}



package com.selfdeveloped.PaymentService.command.api.data;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PaymentRepository extends JpaRepository<Payment, String>{

}


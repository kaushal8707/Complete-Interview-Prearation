package com.java.selfdeveloped.cloud.jenkins.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringIntegrateJenkinsApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.java.core.selfdeveloped.strings;

public class test {
	public static void main(String[] args) {
		String text="abbbccre";
		char chArray[]=text.toCharArray();
		for(int i=0;i<chArray.length;i++) {
			int count=1;
			int j=i+1;

			if(chArray[i]!='0') {
				while(j<chArray.length) {
					if(chArray[i]==chArray[j]) {
						count++;
						chArray[j]='0';
					}
					j++;
				}
			}
			if(count>0) {
				System.out.print(chArray[i]+""+count);
			}
		}
	
	}
}

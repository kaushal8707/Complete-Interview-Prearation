package com.java.core.selfdeveloped.strings;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

//https://www.youtube.com/watch?v=jHj13UHURr8

		


		public class LongestSubStringWithoutRepeatingCharacters {
			public static void main(String[] args) {
				String str="geeksforgeeks";
				Map<String,Integer> map=new HashMap();
				Set<Character> set=new HashSet<Character>();
				int l=0;
				int maxLength=0;
				for(int r=0;r<str.length();r++) {
					if(!set.contains(str.charAt(r))) {
						set.add(str.charAt(r));
						maxLength=Math.max(maxLength, (r-l+1));
					}else {
						while(str.charAt(l)!=str.charAt(r)) {
							set.remove(str.charAt(l));
							l++;
						}
						set.remove(str.charAt(l));
						l++;
						set.add(str.charAt(r));
					}
					//System.out.println(str.substring(l, r+1)+"- "+(r-l+1)); 
					map.put(str.substring(l, r+1), (r-l+1));
				}
		     	String substring=map.entrySet().stream().max(Map.Entry.comparingByValue())
		     							.map(entry->entry.getKey()).get();
		     	System.out.println(substring);
			}
		}

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		//String s="GEEKSFORGEEKS";
		//String s="ABDEFGABEF";
		//String s="bb";
//		String s="geeksforgeeks";
//		 Set<Character>set=new HashSet<>();
//	        int maxLength=0;
//	        int r=0;
//	        int left=0;
//	        for(int right=0;right<s.length();right++){
//	           
//	            if(!set.contains(s.charAt(right))){
//	                set.add(s.charAt(right));
//	                maxLength=Math.max(maxLength,right-left+1);
//	                r=right;
//	                
//	            }else{
//	                while(s.charAt(left)!=s.charAt(right)){
//	                    set.remove(s.charAt(left));
//	                    left++;
//	                }
//	                set.remove(s.charAt(left));
//	                left++;
//	                set.add(s.charAt(right));
//	            }
//	        	System.out.println(right-left+1+"   "+s.substring(left, right+1));
//
//	        }
//
//	}

//}

package com.java.core.selfdeveloped.strings;

public class CountWord_and_ItsLengthInSentence {

	public static void main(String[] args) {
		String str="a";
		boolean flag=checkpalindrome(str);
		if(flag) {
			System.out.println("P");
		}else {
			System.out.println("NP");
		}
	}

	private static boolean checkpalindrome(String str) {
		if(str.length()==0 || str.length()==1)
			return true;
		else {
			if(str.charAt(0)==str.charAt(str.length()-1)) {
				return checkpalindrome(str.substring(1,str.length()-1));
			}
			return false;
		}
			
		
	}
}

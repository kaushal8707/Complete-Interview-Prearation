package com.java.core.selfdeveloped.array;

public class FindFactorial {

	public static void main(String[] args) {
	 int r1 = findFact(5);
	 int r2 = getFact(4);
	 System.out.println(r2+" "+r1);
	 
    }

	private static int getFact(int i) {
		int fact=1;
		while(i>0) {
			fact=fact*i;
			i--;
		}
		return fact;
	}

	private static int findFact(int i) {
		if(i==1)
			return 1;
		return i*findFact(i-1); 
	}
}
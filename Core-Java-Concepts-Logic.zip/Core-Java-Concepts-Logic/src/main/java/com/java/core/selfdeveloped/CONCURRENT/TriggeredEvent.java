package com.java.core.selfdeveloped.CONCURRENT;

public class TriggeredEvent implements Runnable {

	@Override
	public void run() {
		System.out.println(">>>>>>>>>>>>>");

	}

}

package com.java.core.selfdeveloped.practice.RECURSIVE;

public class FibonacciSeries{
    public static void main(String[] args) {
        for(int i=0;i<10;i++){
            System.out.print(fibonacci(i)+" ");
        }
    }
    private static int fibonacci(int n){
        if(n<=1){
            return n;
        }else {
        	return fibonacci(n-1)+fibonacci(n-2);
        }
    }
}
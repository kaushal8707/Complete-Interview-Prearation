package com.java.core.selfdeveloped.break_and_prevent_singleton;

public class SingletonDemo {

	private static SingletonDemo obj;
	private SingletonDemo() {
		
	}
	public static SingletonDemo getObj() {
		if(obj==null) {
		synchronized(SingletonDemo.class) {
			if(obj==null) {
				obj=new SingletonDemo();
			}
		}
	}
		return obj;
	}
}

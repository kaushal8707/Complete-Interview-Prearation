package com.java.core.selfdeveloped.break_and_prevent_singleton;

public class TestSingleTon {

	public static void main(String[] args) {
//		SingletonDemo obj1=SingletonDemo.getObj();
//		SingletonDemo obj2=SingletonDemo.getObj();
//		System.out.println(obj1);
//		System.out.println(obj2);
		
		Thread t1=new Thread(new Runnable() {
			@Override
			public void run() {
				System.out.println(Thread.currentThread().getName()+SingletonDemo.getObj());
			}
		});
		Thread t2=new Thread(new Runnable() {
			@Override
			public void run() {
				System.out.println(Thread.currentThread().getName()+SingletonDemo.getObj());
			}
		});
		t1.start();
		t2.start();

	}

}

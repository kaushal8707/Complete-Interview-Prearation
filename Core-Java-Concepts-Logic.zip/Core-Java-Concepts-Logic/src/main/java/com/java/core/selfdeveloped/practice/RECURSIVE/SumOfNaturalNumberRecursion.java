package com.java.core.selfdeveloped.practice.RECURSIVE;
//1+2+3+4+5+6  = sum(6)
//1+2+3..5 +6
//let n=6
//1+2+...(n-1)+n   = sum(5)+6
//n+sum(n-1)
//taking smallest condition num==0 return 0 bcz its sum if it would be multiply then return 1 for num==0

public class SumOfNaturalNumberRecursion {

	public static void main(String[] args) {
		int n=6;
		int sum=findSumOfNaturalNum(n);
		System.out.println(sum);

	}

	private static int findSumOfNaturalNum(int n) {
		if(n==0) {
			return 0;
		}else {
			return n+findSumOfNaturalNum(n-1);
		}
	}
}

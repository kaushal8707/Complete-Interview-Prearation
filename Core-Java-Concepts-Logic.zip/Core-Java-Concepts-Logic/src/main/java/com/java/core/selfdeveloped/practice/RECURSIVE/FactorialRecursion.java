package com.java.core.selfdeveloped.practice.RECURSIVE;
// 1*2*3*4*5*6  = factorial(6)
//1*2*3..5 *6
//let n=6
//1*2*...(n-1)*n   = factorial(5)*6
//n*factorial(n-1)
//taking smallest condition num==0 return 1 bcz its multiply if it would be sum then return 0 for num==0

public class FactorialRecursion
{
    public static void main(String[] args) {
    int result= FactorialRecursion.factorial(5);
    System.out.println("Factorial = "+result);

    }

    static int factorial(int num)
    {
        if(num==0){
            return 1;	
        }
        return num*factorial(num-1);
    }
}

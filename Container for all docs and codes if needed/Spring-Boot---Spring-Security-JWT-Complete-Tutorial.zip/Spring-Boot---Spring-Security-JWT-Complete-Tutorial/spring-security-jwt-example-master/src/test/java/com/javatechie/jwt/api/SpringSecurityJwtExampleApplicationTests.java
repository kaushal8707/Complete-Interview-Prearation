package com.javatechie.jwt.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSecurityJwtExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}

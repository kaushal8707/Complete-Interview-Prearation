package com.selfdeveloped.jpa.controller;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.selfdeveloped.jpa.dto.OrderRequest;
import com.selfdeveloped.jpa.dto.OrderResponse;
import com.selfdeveloped.jpa.entity.Customer;
import com.selfdeveloped.jpa.repository.CustomerRepository;
import com.selfdeveloped.jpa.repository.ProductRepository;

@RestController
public class OrderController {
	
	Logger logger=LoggerFactory.getLogger(OrderController.class);
    @Autowired
    private CustomerRepository customerRepository;
    @Autowired
    private ProductRepository productRepository;

    @PostMapping("/placeOrder")
    public Customer placeOrder(@RequestBody OrderRequest request){
       return customerRepository.save(request.getCustomer()); 
    }

    @GetMapping("/findAllOrders")
    public List<Customer> findAllOrders(){
        return customerRepository.findAll();
    }
    
    @GetMapping("/getInfo")
    public List<OrderResponse> getJoinInformation(){
        return customerRepository.getJoinInformation();
    }
    
    @PutMapping("/change_customer_data/{id}/{email}")
    public String changeEmail(@PathVariable int id,@PathVariable String email) {
    	customerRepository.changeEmail(id,email);
        logger.info("New Email for customer-id {} is - {}",id,email);
        return "New Email for customer-id"+id+" is - "+email;
    }

    @GetMapping("/customer/{email}")
    public List<Customer> getCustomerByEmail(@PathVariable String email)
    {
         return customerRepository.getCustomerByEmail(email);
    }
    
    @GetMapping("/native/{email}")
    public List<Customer> getAllCustomerByEmails(@PathVariable String email) {
        return customerRepository.getAllCustomerByEmail(email);
    }   

    @GetMapping("/customerByName/{name}")
    public List<Customer> getAllCustomerByNames(@PathVariable String name)
    {
        List<Customer> customerList=customerRepository.getAllCustomerByNames(name);
        logger.info("get All Users By Names - {}",customerList);
        return customerList;
    }
    
    @PutMapping("/update_customer_data/{id}/{email}")
    public String updateCustomerEmail(@PathVariable int id,@PathVariable String email) { 
    	customerRepository.updateEmail(id,email);
        logger.info("New Email for customer-id {} is - {}",id,email);
        return "New Email for customer-id"+id+" is - "+email;
    }
}

package com.selfdeveloped.security.ldap.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringLdapSecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringLdapSecurityApplication.class, args);
	}

}

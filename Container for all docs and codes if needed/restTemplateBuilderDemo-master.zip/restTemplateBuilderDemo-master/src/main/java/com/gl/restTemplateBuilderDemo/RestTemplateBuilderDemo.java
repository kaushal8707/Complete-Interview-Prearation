package com.gl.restTemplateBuilderDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class RestTemplateBuilderDemo {

    public static void main(String[] args) {
        SpringApplication.run(RestTemplateBuilderDemo.class, args);

    }
}


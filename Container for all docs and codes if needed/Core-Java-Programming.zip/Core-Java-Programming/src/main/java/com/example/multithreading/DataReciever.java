package com.example.multithreading;

public class DataReciever {
    static public void show(String data) {
        System.out.println(data);
    }
}

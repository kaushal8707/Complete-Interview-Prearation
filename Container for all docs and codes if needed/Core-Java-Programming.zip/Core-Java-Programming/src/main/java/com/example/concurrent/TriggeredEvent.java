package com.example.concurrent;

public class TriggeredEvent implements Runnable {

	public TriggeredEvent(int i) {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub

	}

}

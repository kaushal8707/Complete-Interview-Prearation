package com.example.threading;

public class DataReciever {
    static public void show(String data) {
        System.out.println(data);
    }
}

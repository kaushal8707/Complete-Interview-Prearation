package com.home.UserInterceptorWithSpringRestAPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserInterceptorWithSpringRestApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserInterceptorWithSpringRestApiApplication.class, args);
	}

}

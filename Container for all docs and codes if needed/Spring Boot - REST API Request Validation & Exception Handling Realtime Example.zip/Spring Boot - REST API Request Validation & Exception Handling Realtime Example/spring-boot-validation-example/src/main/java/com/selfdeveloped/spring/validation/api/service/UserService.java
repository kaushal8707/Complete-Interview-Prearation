package com.selfdeveloped.spring.validation.api.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.selfdeveloped.spring.validation.api.dto.UserRequest;
import com.selfdeveloped.spring.validation.api.entity.User;
import com.selfdeveloped.spring.validation.api.exception.UserNotFoundException;
import com.selfdeveloped.spring.validation.api.repository.UserRepository;

@Service
public class UserService {

	@Autowired
	private UserRepository repository;
	
	
	public User saveUser(UserRequest userRequest) {
		User user=User.build(0, userRequest.getName(), userRequest.getEmail(), 
							  userRequest.getMobile(), userRequest.getGender(), userRequest.getAge(), userRequest.getNationality());
		return repository.save(user);
	}
	
	public List<User> getAllUsers(){
		return repository.findAll();
	}
	
	public User getUser(Integer id) throws UserNotFoundException{
		User user=repository.findByUserId(id);
		if(user!=null) {
			return user;
		}else {
			throw new UserNotFoundException("User not found with id - "+id);
		}
		
	}
	
}

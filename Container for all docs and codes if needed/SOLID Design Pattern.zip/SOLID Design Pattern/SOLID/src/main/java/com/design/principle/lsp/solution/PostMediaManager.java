package com.design.principle.lsp.solution;

public interface PostMediaManager {

    public  void publishPost(Object post);
}

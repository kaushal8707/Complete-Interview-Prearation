package com.design.principle.lsp.solution;

public interface SocialMedia {

    public abstract void chatWithFriend();

    public abstract void sendPhotosAndVideos();

}

package com.always.learner.RestTemplateBuilderApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestTemplateBuilderAppApplicationTests {

	@Test
	void contextLoads() {
	}

}

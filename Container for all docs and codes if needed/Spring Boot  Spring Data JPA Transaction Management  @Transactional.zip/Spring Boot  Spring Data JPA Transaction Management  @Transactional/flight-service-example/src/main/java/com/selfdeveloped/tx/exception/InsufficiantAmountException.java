package com.selfdeveloped.tx.exception;

public class InsufficiantAmountException extends RuntimeException{

	public InsufficiantAmountException(String message) {
		super(message);
	}
}

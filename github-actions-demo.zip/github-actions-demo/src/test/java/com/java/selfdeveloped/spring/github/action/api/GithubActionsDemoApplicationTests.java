package com.java.selfdeveloped.spring.github.action.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GithubActionsDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}

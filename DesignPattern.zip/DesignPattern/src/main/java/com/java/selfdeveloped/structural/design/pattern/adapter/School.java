package com.java.selfdeveloped.structural.design.pattern.adapter;

public class School {

	public static void main(String[] args) {
		//PilotPen pp=new PilotPen();
		Pen p = new PenAdapter();
		AssignmentWork aw = new AssignmentWork();
		aw.setPen(p); 
		aw.writeAssignment("I am bit tired to write an assignment...");
	}
}

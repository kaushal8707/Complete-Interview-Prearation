package com.java.selfdeveloped.creational.design.pattern.factory;

public class Windows implements OS{

	@Override
	public void specs() {
		System.out.println("I am about to die !!!");
	}
}

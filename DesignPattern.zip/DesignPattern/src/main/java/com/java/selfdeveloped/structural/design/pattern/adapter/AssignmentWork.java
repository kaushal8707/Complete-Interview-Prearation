package com.java.selfdeveloped.structural.design.pattern.adapter;

//To write an Assignment we need a Pen …

public class AssignmentWork {

	private Pen pen;
	
	public Pen getPen() {
		return pen;
	}
	public void setPen(Pen pen) {
		this.pen = pen;
	}
	
	public void writeAssignment(String str) {
		pen.write(str); 
	}
}

package com.java.selfdeveloped.creational.design.pattern.singleton;

public class Singleton_Lazy_Without_Synchronized_getInstance {

	public static void main(String[] args) {
		
		Thread t1=new Thread(new Runnable() {	
		public void run() {
			Abn obj1=Abn.getInstance();
			}
		});
		Thread t2=new Thread(new Runnable() {	
			public void run() {
				Abn obj2=Abn.getInstance();
				}
		});
		t1.start();
		t2.start();
	}

}

class Abn{
	static Abn obj;
	private Abn() {
		System.out.println("Instance Created");
	}
	
	public static Abn getInstance(){
		if(obj==null) {
			obj = new Abn();
		}
			return obj;
	}
}

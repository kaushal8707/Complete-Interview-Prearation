package com.java.selfdeveloped.creational.design.pattern.factory;

public interface OS {
	public void specs();
}

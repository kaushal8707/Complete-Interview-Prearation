package com.java.selfdeveloped.creational.design.pattern.factory;

// But we are providing Implementation here Itself….like( new Windows())
// So in future we want to change from Windows to IOS…then  we must have to change the code that means your client
// knows on which class are you working with because you are showing Windows keyword here….
// Now What Factory Design Pattern says Instead of creating directly Object…just create one class name as 
// OperatingSystemFactory, which will give you object of that OS.

public class FactoryMain {

	public static void main(String[] args) {
//		OS os1=new IOS();    //for IOS
//		os1.specs();
//		
//		OS os2=new Android();    //for Android
//		os2.specs();
		
		OperatingSystemFactory osf = new OperatingSystemFactory();
		OS obj=osf.getInstance("Closed");
		obj.specs();
	}
}

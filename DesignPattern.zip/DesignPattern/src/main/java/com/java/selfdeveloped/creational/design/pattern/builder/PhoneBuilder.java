package com.java.selfdeveloped.creational.design.pattern.builder;

public class PhoneBuilder {
	private String os;
	private int ram;
	private String processor;
	private double screenSize;
	private int battery;
	
	public PhoneBuilder setOs(String os) {
		this.os = os;
		return this;
	}
	
	public PhoneBuilder setRam(int ram) {
		this.ram = ram;
		return new PhoneBuilder();
	}


	public PhoneBuilder setProcessor(String processor) {
		this.processor = processor;
		return new PhoneBuilder();
	}
	public PhoneBuilder setScreenSize(double screenSize) {
		this.screenSize = screenSize;
		return new PhoneBuilder();
	}
	public PhoneBuilder setBattery(int battery) {
		this.battery = battery;
		return new PhoneBuilder();
	}
	
	public Phone getPhone() {
		Phone p = new Phone(os, ram, processor, screenSize, battery);
		return p;
	}
	
	
}

package com.java.selfdeveloped.creational.design.pattern.singleton;

public class Singleton_Using_Synchronized_getInstance {

	public static void main(String[] args) {
		
		Thread t1=new Thread(new Runnable() {	
		public void run() {
			Abm obj1=Abm.getInstance();
			}
		});
		Thread t2=new Thread(new Runnable() {	
			public void run() {
			Abm obj2=Abm.getInstance();
				}
		});
		t1.start();
		t2.start();
	}

}

class Abm{
	static Abm obj;
	private Abm() {
		System.out.println("Instance Created");
	}
	
	public static synchronized Abm getInstance(){
		if(obj==null) {
			obj = new Abm();
		}
			return obj;
	}
}

package com.java.selfdeveloped.creational.design.pattern.factory;

public class IOS implements OS{

	@Override
	public void specs() {
		System.out.println("Most Powerful OS");
	}
}

package com.selfdeveloped.event.listener;
import java.util.UUID;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

import com.selfdeveloped.entity.User;
import com.selfdeveloped.event.RegistrationCompleteEvent;
import com.selfdeveloped.service.UserService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class RegistrationCompleteEventListener implements ApplicationListener<RegistrationCompleteEvent> {

	@Autowired
	private UserService userService;
	
	@Override
	public void onApplicationEvent(RegistrationCompleteEvent event) {
		//create the Verification token for the User with the link
		User user=event.getUser();
		String token=UUID.randomUUID().toString();
		userService.saveVerificationTokenForUser(token,user);
		//send mail to the User
		String url =
				event.getApplicationUrl()+"/verifyRegistration?token="+token;
		//sendVerificationEmail()
		log.info("click the link to verify your account: {}",url);
	}
}



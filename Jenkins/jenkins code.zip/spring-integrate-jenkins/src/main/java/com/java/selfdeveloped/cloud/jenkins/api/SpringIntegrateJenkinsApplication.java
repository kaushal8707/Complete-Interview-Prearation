package com.java.selfdeveloped.cloud.jenkins.api;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;


import jakarta.annotation.PostConstruct;

@SpringBootApplication
@RestController
public class SpringIntegrateJenkinsApplication {

	public static Logger logger = LoggerFactory.getLogger(SpringIntegrateJenkinsApplication.class);

	@GetMapping("/ping")
	public String message() {
		return "Wao!! Application Deployed successfully in SAP Cloud..";
	}
	
	@PostConstruct
	public void init() {
		logger.info("Application started !!");

	}
	
	public static void main(String[] args) {
		SpringApplication.run(SpringIntegrateJenkinsApplication.class, args);
	}

}

package com.selfdeveloped.jpa.indepth.repository;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.selfdeveloped.jpa.indepth.entity.Course;
import com.selfdeveloped.jpa.indepth.entity.Teacher;

@SpringBootTest
class TeacherRepositoryTest {

	@Autowired
	private TeacherRepository teacherRepository;
	
	@Test
	public void saveTeacher(){ 
		
		List<Course> course = 
				Stream.of(new Course("DS", 12),
						new Course("SPRING", 9)).collect(Collectors.toList()); 
		
		Teacher teacher = 
				Teacher.builder()
				.firstName("Bharat")
				.lastName("Bhushan")
				//.course(course) 
				.build();
		teacherRepository.save(teacher);
	} 
}

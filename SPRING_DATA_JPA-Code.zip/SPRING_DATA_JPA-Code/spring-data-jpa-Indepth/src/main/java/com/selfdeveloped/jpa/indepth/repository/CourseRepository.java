package com.selfdeveloped.jpa.indepth.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.selfdeveloped.jpa.indepth.entity.Course;

public interface CourseRepository extends JpaRepository<Course,Long>{

}

# Microservice-Day-14---Spring-Boot-Spring-Data-JPA-Many-to-Many-Bidirectional-Relationship-Example

Payload- json

{
    "name": "Bharat",
    "age": 30,
    "dept": "DEV",
    "courses": [
        {
            "title": "Machine Learning",
            "abbreviation": "ML",
            "modules": 10,
            "fee": 4000
        },
        {
            "title": "Spring Boot",
            "abbreviation": "SB",
            "modules": 11,
            "fee": 2500
        },
        {
            "title": "Database Systems",
            "abbreviation": "DS",
            "modules": 5,
            "fee": 1800
        }
    ]
}

package com.java.selfdeveloped.patch.mapping.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import com.java.selfdeveloped.patch.mapping.entity.Product;

public interface ProductRepository extends
        JpaRepository<Product, Integer> {


}

package com.java.selfdeveloped.spring.java8.api.lambda.exression;
@FunctionalInterface
public interface Calculator {

	//void switchOn();
	void printNum(int num);

}

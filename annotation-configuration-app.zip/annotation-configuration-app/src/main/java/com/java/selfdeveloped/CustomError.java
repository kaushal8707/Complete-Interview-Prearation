package com.java.selfdeveloped;
import org.springframework.http.HttpStatus;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class CustomError {
	private String errorCode;
	private String message;
	private HttpStatus status;
}

package com.java.selfdeveloped;

public class TestBean {

    public void method(){
        System.out.println("TestBean method logic excuted ");
    }
}

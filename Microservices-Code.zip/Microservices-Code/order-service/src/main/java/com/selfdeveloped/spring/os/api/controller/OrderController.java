package com.selfdeveloped.spring.os.api.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.selfdeveloped.spring.os.api.common.Payment;
import com.selfdeveloped.spring.os.api.common.TransactionRequest;
import com.selfdeveloped.spring.os.api.common.TransactionResponse;
import com.selfdeveloped.spring.os.api.entity.Order;
import com.selfdeveloped.spring.os.api.service.OrderService;

@RestController
@RequestMapping("/order")
public class OrderController {

	@Autowired
	OrderService orderService;
	
	@PostMapping("/bookOrder")
	public TransactionResponse bookOrder( @RequestBody TransactionRequest request) {
		return orderService.saveOrder(request);
	}	
}
 
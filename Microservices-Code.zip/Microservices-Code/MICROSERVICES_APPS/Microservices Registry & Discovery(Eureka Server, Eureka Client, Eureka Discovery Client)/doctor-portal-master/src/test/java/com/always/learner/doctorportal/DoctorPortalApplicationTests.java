package com.always.learner.doctorportal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DoctorPortalApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.example.patientService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PatientServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}

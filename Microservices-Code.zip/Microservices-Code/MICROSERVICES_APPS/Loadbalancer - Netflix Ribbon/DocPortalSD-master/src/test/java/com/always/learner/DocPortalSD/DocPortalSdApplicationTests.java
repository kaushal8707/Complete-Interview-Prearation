package com.always.learner.DocPortalSD;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DocPortalSdApplicationTests {

	@Test
	void contextLoads() {
	}

}

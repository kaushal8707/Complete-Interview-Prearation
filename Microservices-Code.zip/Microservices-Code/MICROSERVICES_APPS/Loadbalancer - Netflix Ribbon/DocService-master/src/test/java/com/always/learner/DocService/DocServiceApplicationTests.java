package com.always.learner.DocService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DocServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}

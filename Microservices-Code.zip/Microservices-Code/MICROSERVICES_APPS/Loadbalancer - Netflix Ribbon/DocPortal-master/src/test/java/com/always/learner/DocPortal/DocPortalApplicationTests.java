package com.always.learner.DocPortal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DocPortalApplicationTests {

	@Test
	void contextLoads() {
	}

}

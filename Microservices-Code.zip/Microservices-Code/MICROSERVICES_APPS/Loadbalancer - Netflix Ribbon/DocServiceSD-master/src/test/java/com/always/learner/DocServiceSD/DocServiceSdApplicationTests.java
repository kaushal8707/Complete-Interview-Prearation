package com.always.learner.DocServiceSD;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DocServiceSdApplicationTests {

	@Test
	void contextLoads() {
	}

}

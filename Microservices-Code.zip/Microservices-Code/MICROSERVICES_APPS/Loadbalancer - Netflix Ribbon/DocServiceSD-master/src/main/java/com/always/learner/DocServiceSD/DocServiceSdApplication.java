package com.always.learner.DocServiceSD;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DocServiceSdApplication {

	public static void main(String[] args) {
		SpringApplication.run(DocServiceSdApplication.class, args);
	}

}

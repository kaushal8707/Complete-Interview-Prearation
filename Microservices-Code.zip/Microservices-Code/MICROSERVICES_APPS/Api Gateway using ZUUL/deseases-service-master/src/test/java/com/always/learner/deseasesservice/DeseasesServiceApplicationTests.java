package com.always.learner.deseasesservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DeseasesServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}

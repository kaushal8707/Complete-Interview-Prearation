package com.always.learner.deseasesservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DeseasesServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(DeseasesServiceApplication.class, args);
	}

}

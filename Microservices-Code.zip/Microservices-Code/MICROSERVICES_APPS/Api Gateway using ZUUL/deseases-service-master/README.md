# deseases-service   
API Gateway

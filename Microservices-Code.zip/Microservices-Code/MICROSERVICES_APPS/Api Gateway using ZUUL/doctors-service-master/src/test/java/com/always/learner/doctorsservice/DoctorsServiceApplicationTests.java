package com.always.learner.doctorsservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DoctorsServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.always.learning.UserManagementClient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserManagementClientApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.always.learner.OrderManagementService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrderManagementServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}

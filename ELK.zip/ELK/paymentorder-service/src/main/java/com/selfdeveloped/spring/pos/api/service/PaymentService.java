package com.selfdeveloped.spring.pos.api.service;
import java.util.Random;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.selfdeveloped.spring.pos.api.entity.Payment;
import com.selfdeveloped.spring.pos.api.repository.PaymentRepository;

@Service
public class PaymentService {

	@Autowired
	PaymentRepository paymentRepository;
	
	private Logger log=LoggerFactory.getLogger(PaymentService.class);
	
	public Payment doPayment(Payment payment) throws JsonProcessingException {
		payment.setPaymentStatus(paymentProcessing()); 
		payment.setTransactionId(UUID.randomUUID().toString());
		log.info("Payment Service request : {} ", new ObjectMapper().writeValueAsString(payment));
		return paymentRepository.save(payment);
	}
	
	
	public String paymentProcessing() {
		//api should be 3rd party payment gateway (PayPal, paytm, GooglePay…)
		return new Random().nextBoolean()?"Success":"Failed";
	}


	public Payment findPaymentHistoryByOrderId(int orderId) { 
		Payment payment=paymentRepository.findByOrderId(orderId);
		log.info("PaymentService findPaymentHistoryByOrderId : {} ", payment);
		return payment;
	}
	
}

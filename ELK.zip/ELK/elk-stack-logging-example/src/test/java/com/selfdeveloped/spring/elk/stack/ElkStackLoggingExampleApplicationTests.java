package com.selfdeveloped.spring.elk.stack;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ElkStackLoggingExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}

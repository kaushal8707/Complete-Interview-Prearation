package com.java.selfdeveloped.spring.crud.k8s.configmap.secretapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootCrudK8sConfigmapSecretDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootCrudK8sConfigmapSecretDemoApplication.class, args);
	}

}

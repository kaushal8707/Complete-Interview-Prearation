package com.java.selfdeveloped.spring.docker.k8s.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootK8sApplicationTests {

	@Test
	void contextLoads() {
	}

}

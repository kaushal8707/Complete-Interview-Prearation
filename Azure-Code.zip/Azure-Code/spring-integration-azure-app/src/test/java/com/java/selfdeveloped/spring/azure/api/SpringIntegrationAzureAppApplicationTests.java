package com.java.selfdeveloped.spring.azure.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringIntegrationAzureAppApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.java.selfdeveloped.spring.azure.sql.api;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EmployeeRepository extends JpaRepository<Employee,Integer> {
}


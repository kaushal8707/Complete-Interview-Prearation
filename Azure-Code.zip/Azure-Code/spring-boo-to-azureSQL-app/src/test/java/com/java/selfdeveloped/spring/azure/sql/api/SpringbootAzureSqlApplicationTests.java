package com.java.selfdeveloped.spring.azure.sql.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootAzureSqlApplicationTests {

	@Test
	void contextLoads() {
	}

}

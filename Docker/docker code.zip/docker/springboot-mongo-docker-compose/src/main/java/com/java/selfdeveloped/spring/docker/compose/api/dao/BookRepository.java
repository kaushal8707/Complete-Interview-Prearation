package com.java.selfdeveloped.spring.docker.compose.api.dao;
import org.springframework.data.mongodb.repository.MongoRepository;
import com.java.selfdeveloped.spring.docker.compose.api.model.Book;

public interface BookRepository extends MongoRepository<Book,Integer> {
}
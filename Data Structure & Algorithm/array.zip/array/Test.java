package com.java.core.selfdeveloped.array;

public class Test {
	//finding duplicates in a sorted array
	public static void main(String[] args) {
		int arr[]= {3,6,8,8,10,12,15,15,15,20};
		for(int i=0;i<arr.length;i++) {
			
		}

	}
}

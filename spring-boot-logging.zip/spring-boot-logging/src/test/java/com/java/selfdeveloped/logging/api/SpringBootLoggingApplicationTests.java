package com.java.selfdeveloped.logging.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootLoggingApplicationTests {

	@Test
	void contextLoads() {
	}

}

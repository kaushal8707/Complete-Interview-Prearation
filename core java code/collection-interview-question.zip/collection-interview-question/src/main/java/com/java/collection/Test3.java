package com.java.collection;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Test3 {
	public static void main(String[] args) {
			Set<Student> set = new HashSet<>();
			
			Student s1 = new Student(101, "Kaushal");
			Student s2 = new Student(101, "Kaushal");
			Student s3 = new Student(105, "Prakash");
			set.add(s1);
			set.add(s2);
			set.add(s3);

			System.out.println(set);

	}
}

package com.java.collection;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MainComparatorApp {

	public static void main(String[] args) {
		List<Employee> list = new ArrayList<>();
		Employee e1 = new Employee(101, "Kaushal");
		Employee e2 = new Employee(109, "Kanishk");
		Employee e3 = new Employee(105, "Prakash");
		Employee e4 = new Employee(98, "Basant");
		Employee e5 = new Employee(101, "Baikash");
		list.add(e1);list.add(e2);list.add(e3);
		list.add(e4);list.add(e5);
		Collections.sort(list, new IdComparator());
		System.out.println(list);
	}
}

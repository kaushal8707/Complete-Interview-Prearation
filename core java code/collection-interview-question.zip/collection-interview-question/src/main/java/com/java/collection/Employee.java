package com.java.collection;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

public class Employee implements Comparable<Employee> { 

	private int id;
	private String name;
	public Employee(int id, String name) {
		this.id = id;
		this.name = name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
//	@Override
//	public int compareTo(Employee e) {
//		if(id==e.id) {
//			return 0;
//		}else if(id>e.id) {
//			return 1;
//		}else {
//			return -1;
//		}
//	}
	
	//sorting based on name
	@Override
	public int compareTo(Employee e) {
		return this.name.compareTo(e.getName());
	}
	
	
	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + "]";
	} 
	@Override
	public int hashCode() {
		return Objects.hash(id, name);
	}
	
	public static void main(String[] args) {
		List<Employee> list = new ArrayList<>();
		Employee e1 = new Employee(101, "Kaushal");
		Employee e2 = new Employee(109, "Kanishk");
		Employee e3 = new Employee(105, "Prakash");
		list.add(e1);list.add(e2);list.add(e3);
		Collections.sort(list);
		System.out.println(list);
	}

}

package com.java.collection;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class Test1 {
	public static void main(String[] args) {
		try {
		final List list = new ArrayList<String>();
		list.add("a");
		list.add("b");
		System.out.println(list);
		//list=new ArrayList();
		
		List immutableList = Collections.unmodifiableList(list);
		immutableList.add("d");
		System.out.println(immutableList);
		}catch (UnsupportedOperationException e) {
	            System.out.println("Exception thrown : " + e);
	        }

	}
}
